Arshia Behzad
2320643
behzad@chapman.edu
CPSC 298 C++


Source Files: Ch1Ex1.cpp, Ch1Ex3.cpp, Ch1Ex5.cpp, 
Ch2Ex2.cpp, Ch2Ex4.cpp, Ch2Ex6.cpp

For the first two assignments I asked Stephen White a few questions 
for Ch2Ex6.cpp I went on stackoverflow and learned about how to use pi
using "#define _USE_MATH_DEFINES" 

